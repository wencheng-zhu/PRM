#!/bin/bash

function show_help() {
cat << EOF
Usage: bash $BASH_SOURCE [-h|--help] --dir DIR
    --dir: model dir
    --max-thread: maximum thread number of testing.

e.g.
    bash $BASH_SOURCE --dir ../models/conv16/
EOF
}

trap 'jobs -p | xargs kill' SIGINT
set -e

MAX_THREAD=20

SPLIT=split_davis2017_test.json
RESULT_NAME=results

while [[ $# -gt 0 ]]
do
    case $1 in
        --dir)
            DIR=$2
            shift 2
            ;;
        --split)
            SPLIT=$2
            shift 2
            ;;
        --result-name)
            RESULT_NAME=$2
            shift 2
            ;;
        *)
            show_help
            exit 1
            ;;
    esac
done

if [[ -z $DIR || -z $SPLIT ]]
then
    show_help
    exit 1
fi

ROOT=$(pwd)

for CKPT in $(ls $DIR/$RESULT_NAME)
do
    if [[ -d "$ROOT/$DIR/$RESULT_NAME/$CKPT/$SPLIT.final/" ]]
    then
        if [[ $SPLIT = "split_davis2017_test.json" ]]
        then
            cd $ROOT/$DIR/$RESULT_NAME/$CKPT/$SPLIT.final/
            zip -r $CKPT.zip .
        else
            cd $ROOT/$DIR/$RESULT_NAME/$CKPT
            mv $SPLIT.final/ Annotations/
            zip -r $CKPT.zip Annotations/
            mv Annotations/ $SPLIT.final/
        fi
        mv $CKPT.zip ~/
    fi
done
wait
