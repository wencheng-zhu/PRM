#!/bin/bash

function show_help() {
cat << EOF
Usage: bash $BASH_SOURCE [-h|--help] --dir DIR [--max-thread MAX_THREAD]
    --dir: model dir
    --max-thread: maximum thread number of testing.

e.g.
    bash $BASH_SOURCE --dir ../models/conv16/ --max-thread 20
EOF
}

trap 'jobs -p | xargs kill' SIGINT
set -e

MAX_THREAD=20

SPLIT=split_davis2017_val.json
RESULT_NAME=results

while [[ $# -gt 0 ]]
do
    case $1 in
        --dir)
            DIR=$2
            shift 2
            ;;
        --max-thread)
            MAX_THREAD=$2
            shift 2
            ;;
        --result-name)
            RESULT_NAME=$2
            shift 2
            ;;
        *)
            show_help
            exit 1
            ;;
    esac
done

if [[ -z $DIR || -z $SPLIT ]]
then
    show_help
    exit 1
fi

echo "test snapshots in $DIR with $SPLIT with gpus $GPU."

for CKPT in $(ls $DIR/$RESULT_NAME)
do
    while (( $(jobs -p | wc -l) >= $MAX_THREAD ))
    do
        sleep 1
    done
    python ../../davis2017-evaluation/evaluation_method.py --davis_path /opt/data7/wencheng/DAVIS2017/DAVIS --task semi-supervised --results_path $DIR/$RESULT_NAME/$CKPT/$SPLIT.final/ &
    python ../../davis2017-evaluation/evaluation_method.py --davis_path /opt/data7/wencheng/DAVIS2017/DAVIS --task semi-supervised --results_path $DIR/$RESULT_NAME/$CKPT/$SPLIT.soft.final/ &
done
wait

# save data
for CKPT in $(ls $DIR/$RESULT_NAME)
do
    while (( $(jobs -p | wc -l) >= $MAX_THREAD ))
    do
        sleep 1
    done
    RESULT=$(cat $DIR/$RESULT_NAME/$CKPT/$SPLIT.final/global_results-val.csv | tail -n 1)
    echo "$CKPT, $RESULT" >> davis2017.txt
    RESULT=$(cat $DIR/$RESULT_NAME/$CKPT/$SPLIT.soft.final/global_results-val.csv | tail -n 1)
    echo "$CKPT, $RESULT" >> davis2017.txt
done
