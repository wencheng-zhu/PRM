#!/bin/bash

function show_help() {
cat << EOF
Usage: bash $BASH_SOURCE
    --split-val SPLIT_VAL split name
    --gpu GPU gpu indices for testing. 
    --model-dir MODEL_DIR model dir
    --max-thread MAX_THREAD: maximum thread number of testing.
    --result-name RESULT_NAME: result directory name
    --matching|--keep-topk|--fix-margin|--input-height|--input-width|--fuse-mode|--encoder|--self-structure PARAM
    --no-pixel|--average|--no-crop|--no-decoder|--region-conv|--final-mask|--noise

e.g.
    bash $BASH_SOURCE --split-val ../splits/split_davis2017_val.json --gpu 0,1,2,3 --model-dir ../models/conv16/ --matching conv --max-thread 20
EOF
}

set -e
trap 'jobs -p | xargs kill' SIGINT

MAX_THREAD=20
RESULT_NAME=results
ARGS=""

while [[ $# -gt 0 ]]
do
    case $1 in
        --split-val)
            ARGS="$ARGS $1 $2"
            SPLIT=$2
            shift 2
            ;;
        --gpu)
            GPU=$2
            shift 2
            ;;
        --model-dir)
            DIR=$2
            ARGS="$ARGS $1 $2"
            shift 2
            ;;
        --max-thread)
            MAX_THREAD=$2
            shift 2
            ;;
        --result-name)
            RESULT_NAME=$2
            shift 2
            ;;
        --matching|--keep-topk|--fix-margin|--input-height|--input-width|--fuse-mode|--encoder|--self-structure)
            ARGS="$ARGS $1 $2"
            shift 2
            ;;
        --no-pixel|--average|--no-crop|--no-decoder|--region-conv|--final-mask|--noise)
            ARGS="$ARGS $1"
            shift 1
            ;;
        *)
            show_help
            echo "unexpected arg $1"
            exit 1
            ;;
    esac
done

if [[ -z $DIR || -z $SPLIT || -z $GPU ]]
then
    show_help
    exit 1
fi

# extract the base filename
while [[ $SPLIT == *"/"* ]]
do
    SPLIT="${SPLIT#*/}"
done

echo "test snapshots in $DIR with $SPLIT with gpus $GPU."
GPU=($(echo $GPU | tr ',' ' '))
GPU_IDX=0

for CKPT in $(ls $DIR/checkpoints/)
do
    while (( $(jobs -p | wc -l) >= $MAX_THREAD ))
    do
        sleep 5
    done

    echo "evaluating $CKPT"
    if [[ -d "$DIR/$RESULT_NAME/$CKPT/$SPLIT.final/" ]]
    then
        echo 'continue'
        continue
    fi

    echo $ARGS
    CUDA_VISIBLE_DEVICES=${GPU[$GPU_IDX]} python ../src/evaluate.py --resume $DIR/checkpoints/$CKPT --save-dir $DIR/$RESULT_NAME/$CKPT/$SPLIT $ARGS && \
    python ../src/merge_masks.py --dir $DIR/$RESULT_NAME/$CKPT/$SPLIT/ --save-dir $DIR/$RESULT_NAME/$CKPT/$SPLIT.final/ && \
    python ../src/merge_masks.py --dir $DIR/$RESULT_NAME/$CKPT/$SPLIT/ --save-dir $DIR/$RESULT_NAME/$CKPT/$SPLIT.soft.final/ --soft && \
    rm -r $DIR/$RESULT_NAME/$CKPT/$SPLIT/ &
    GPU_IDX=$(( ($GPU_IDX + 1) % ${#GPU[*]} ))
done
wait

if [[ $SPLIT = 'split_davis2016_val.json' ]]
then
    bash davis16_val.sh --dir $DIR --max-thread 20 --result-name $RESULT_NAME
elif [[ $SPLIT = 'split_davis2017_val.json' ]]
then
    bash davis17_val.sh --dir $DIR --max-thread 20 --result-name $RESULT_NAME
elif [[ $SPLIT = 'split_davis2017_test.json' ]]
then
    bash davis17_test.sh --dir $DIR --result-name $RESULT_NAME
elif [[ $SPLIT = 'split_youtube_test.json' ]]
then
    bash davis17_test.sh --dir $DIR --split $SPLIT --result-name $RESULT_NAME
fi
