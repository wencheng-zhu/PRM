# youtube
CUDA_VISIBLE_DEVICES=0,1 python train.py --model-dir ../models/conv17 --split-train ../splits/split_youtube_train.json --matching conv --self-structure cluster --region-conv --fuse-mode region-attn

# davis17 20 checkpoints
CUDA_VISIBLE_DEVICES=0,1 python train.py --model-dir ../models/convytb_vf17 --max-epoch 20 --split-train ../splits/split_davis2017_train.json --matching conv --resume ../models/convytb/checkpoints/80999.pt --base-lr 1e-6 --save-step 640 --lr-decay-step 640 --self-structure cluster --region-conv --fuse-mode region-attn

# davis16
CUDA_VISIBLE_DEVICES=0,1 python train.py --model-dir ../models/convytb_vf16 --max-epoch 100 --split-train ../splits/split_davis2016_train.json --matching conv --resume ../models/convytb/checkpoints/80999.pt --base-lr 1e-6 --save-step 130 --lr-decay-step 650 --self-structure cluster --region-conv --fuse-mode region-attn

# coco
CUDA_VISIBLE_DEVICES=0,1,2,3 python train.py --model-dir ../models/conv17 --split-train ../splits/split_coco_train.json --matching conv --region-conv --fuse-mode region-attn --lr-decay-step 9999999999 --save-step 10000
