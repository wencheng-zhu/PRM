# python ../src/eval_previous_mask.py -model_name=one-shot-model-davis -dataset=davis2017 -eval_split=val -batch_size=1 -length_clip=130 -gpu_id=0

CUDA_VISIBLE_DEVICES=0 python evaluate.py --resume ../models/checkpoints/1.pt --save-dir ../models/temp --split-val ../splits/split_davis2017_val.json --matching conv

python merge_masks.py --dir ../models/prnet2/results/ --save-dir ../models/prnet2/results_final

cd ../../davis2017-evaluation/
# 2017
python evaluation_method.py --davis_path /opt/data7/wencheng/DAVIS2017/DAVIS --task semi-supervised --results_path ../rvos/models/prnet2/results_final
# 2016
python evaluation_method.py --davis_path /opt/data7/wencheng/DAVIS2016/DAVIS/ --task semi-supervised --results_path ../rvos/models/prnet2/results_final
