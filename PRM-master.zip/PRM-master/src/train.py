import json
import logging
import os
import time

import numpy as np
import torch
from tensorboardX import SummaryWriter
from torch import nn
from torch.optim import Adam
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import DataLoader
from torchvision import transforms

import init_helper
import metrics
from dataloader.dataset import TrainDataset
from modules.prm import PRNet

logger = logging.getLogger()


def main():
    args = init_helper.get_arguments()

    os.makedirs(args.model_dir, exist_ok=True)
    os.makedirs(os.path.join(args.model_dir, "checkpoints"), exist_ok=True)

    init_helper.init_logger(os.path.join(args.model_dir, "logs"), "train.log")
    init_helper.set_random_seed(args.seed)

    with open(os.path.join(args.model_dir, "args.json"), "w") as f:
        json.dump(vars(args), f, indent=4, separators=(",", ": "))

    model = PRNet(args.encoder, args.matching, args.keep_topk, args.pixel, args.average, args.decoder,
                  args.self_structure, args.region_conv, args.fuse_mode, args.final_mask).cuda()
    parallel_model = nn.DataParallel(model, device_ids=list(range(torch.cuda.device_count())))

    logger.info(args)

    trainable_params = [{"params": model.encoder.parameters(), "lr": args.base_lr * args.encoder_lr_weight},
                        {"params": list(set(model.parameters()) - set(model.encoder.parameters())), "lr": args.base_lr}]

    optimizer = Adam(trainable_params, lr=args.base_lr, weight_decay=0.0005)

    lr_manager = StepLR(optimizer, step_size=args.lr_decay_step, gamma=args.lr_decay_rate)

    global_step = 0

    if args.resume is not None:
        checkpoint = torch.load(args.resume)
        model.load_state_dict(checkpoint["model_dict"])
        if args.resume_step:
            global_step = checkpoint["global_step"] + 1

    start = time.time()

    train_sequence = []
    for split_filename in args.split_train:
        with open(split_filename, "r") as f:
            train_sequence += json.load(f)

    train_dataset = TrainDataset(train_sequence, args.input_height, args.input_width, args.min_margin, 
                                args.max_margin, args.flip_rate, args.rotation, args.blur_rate, args.blur_mode, args.noise)
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)

    criterion = nn.CrossEntropyLoss().cuda()

    with SummaryWriter(os.path.join(args.model_dir, "board")) as writer:

        for epoch in range(args.max_epoch):
            logger.info(f"Epoch {epoch} started")

            train_losses = []
            train_jaccards = []

            for batch_index, (image_ref, mask_ref, image_cur, mask_cur, mask_prev, crop_box) in enumerate(train_loader):

                if args.visualize:
                    import cv2
                    cv2.imshow("image_ref", image_ref[0].cpu().numpy().transpose(1, 2, 0))
                    cv2.imshow("mask_ref", mask_ref[0].cpu().numpy().squeeze())
                    cv2.imshow("image_cur", image_cur[0].cpu().numpy().transpose(1, 2, 0))
                    cv2.imshow("mask_cur", mask_cur[0].cpu().numpy().squeeze())
                    cv2.imshow("mask_prev", mask_prev[0].cpu().numpy().squeeze())
                    cv2.imshow("fg_cur", mask_cur[0].squeeze().unsqueeze(-1).cpu().numpy() * image_cur[0].cpu().numpy().transpose(1, 2, 0))
                    cv2.imshow("fg_ref", mask_ref[0].squeeze().unsqueeze(-1).cpu().numpy() * image_ref[0].cpu().numpy().transpose(1, 2, 0))
                    cv2.waitKey(1)

                model.train()

                image_ref = image_ref.cuda()
                image_cur = image_cur.cuda()
                mask_ref = mask_ref.cuda()
                mask_cur = mask_cur.cuda()
                mask_prev = mask_prev.cuda()

                pred_mask = parallel_model(image_ref, mask_ref, image_cur, mask_prev)

                pred_mask = pred_mask.permute(0, 2, 3, 1).contiguous().view(-1, 2)
                mask_cur = mask_cur.view(-1).type(torch.long)
                loss = criterion(pred_mask, mask_cur)
                loss = torch.mean(loss)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                train_losses.append(loss.data.item())

                mask_cur = mask_cur.cpu().numpy()

                pred_mask = torch.argmax(pred_mask, dim=1)
                pred_mask = pred_mask.cpu().numpy()

                train_jaccard = metrics.jaccard(mask_cur, pred_mask)
                train_jaccards.append(train_jaccard)

                writer.add_scalar("train/loss", loss.data.item(), global_step=global_step)
                writer.add_scalar("train/jaccard", train_jaccard, global_step=global_step)

                if global_step % args.lr_decay_step == 0:
                    for idx, param_group in enumerate(optimizer.param_groups):
                        group_lr = param_group["lr"]
                        logger.info(f"learning rate of group {idx} decayed to {group_lr}")
                        writer.add_scalar(f"lr/group_{idx}", group_lr, global_step=global_step)

                # log
                if (global_step + 1) % args.log_step == 0:
                    time_elapsed = time.time() - start
                    logger.info(f"step {global_step} ({epoch}, {batch_index}): train loss: {loss.data.item():.4f} "
                                f"jaccard: {train_jaccard:.4f} time: {time_elapsed:.4f}")
                    start = time.time()

                if (global_step + 1) % args.save_step == 0:
                    logger.info(f"step {global_step} ({epoch}, {batch_index}): saving checkpoint")
                    torch.save({
                        "model_dict": model.state_dict(),
                        "global_step": global_step
                    }, os.path.join(args.model_dir, "checkpoints", f"{global_step}.pt"))

                lr_manager.step()
                global_step += 1

            train_loss = np.mean(train_losses)
            train_jaccard = np.mean(train_jaccards)

            logger.info(f"epoch {epoch}: train loss: {train_loss:.4f} jaccard: {train_jaccard:.4f}")


if __name__ == "__main__":
    main()
