import argparse
import os
import cv2
import numpy as np


def visualize_mask(mask):
    height, width = mask.shape
    colors = np.array([0x000000, 0xff0000, 0x00ff00, 0x0000ff, 0xffff00,
                       0xff00ff, 0x00ffff, 0x770000, 0x007700, 0x000077,
                       0x007777, 0x770077, 0x777700], dtype=np.int32)
    if mask.max() >= len(colors):
        return mask
    mask_int = colors[mask]

    mask_colored = np.zeros((height, width, 3))
    mask_colored[:, :, 0] = (mask_int & 0xff)
    mask_colored[:, :, 1] = ((mask_int >> 8) & 0xff)
    mask_colored[:, :, 2] = ((mask_int >> 16) & 0xff)
    return mask_colored


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dir', type=str, required=True)
    parser.add_argument('--save-dir', type=str, required=True)
    parser.add_argument('--soft', action='store_true')
    parser.add_argument('--visualize', action='store_true')
    args = parser.parse_args()

    for video_name in os.listdir(args.dir):
        video_dir = os.path.join(args.dir, video_name)
        object_indices = os.listdir(video_dir)

        mask_filenames = []
        for idx in object_indices:
            mask_filenames += os.listdir(os.path.join(video_dir, idx))

        mask_filenames = sorted(list(set(mask_filenames)))

        for mask_filename in mask_filenames:
            scores = None
            for (score_index, object_index) in enumerate(object_indices):
                mask_path = os.path.join(video_dir, object_index, mask_filename)

                if not os.path.isfile(mask_path):
                    continue

                cur_score = cv2.imread(mask_path, cv2.COLOR_BGR2GRAY).astype(np.float32)
                cur_score /= 255

                # if final_mask is None or final_score is None:
                if scores is None:
                    scores = np.zeros((len(object_indices) + 1, *cur_score.shape), dtype=np.float32)
                    scores[0] = 1.0

                scores[score_index + 1] = cur_score # object score

                if args.soft:
                    scores[0] *= 1 - cur_score
                else:
                    scores[0] = np.minimum(scores[0], 1 - cur_score)

            final_mask = np.argmax(scores, axis=0).astype(np.int32)
            final_mask = np.array([0, *object_indices], dtype=np.int32)[final_mask]

            if args.visualize:
                mask_display = visualize_mask(final_mask)
                cv2.imshow('mask', mask_display)
                cv2.waitKey(1)

            save_dir = os.path.join(args.save_dir, video_name)

            os.makedirs(save_dir, exist_ok=True)
            cv2.imwrite(os.path.join(save_dir, mask_filename), final_mask.astype(np.uint8))


if __name__ == "__main__":
    main()
