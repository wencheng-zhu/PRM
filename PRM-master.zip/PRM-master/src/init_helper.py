import argparse
import logging
import torch
import random
import numpy as np
import os


def init_logger(log_dir, log_file):
    logger = logging.getLogger()
    format_str = '[%(asctime)s %(filename)s#%(lineno)3d] %(message)s'
    logging.basicConfig(
        level=logging.INFO,
        datefmt='%Y/%m/%d %H:%M:%S',
        format=format_str
    )
    os.makedirs(log_dir, exist_ok=True)
    fh = logging.FileHandler(os.path.join(log_dir, log_file))
    fh.setFormatter(logging.Formatter(format_str))
    logger.addHandler(fh)


def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)


def get_arguments():
    parser = argparse.ArgumentParser()

    # training
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--max-epoch', type=int, default=20)
    parser.add_argument('--num-workers', type=int, default=16)
    parser.add_argument('--visualize', action='store_true')
    parser.add_argument('--resume', type=str, default=None)
    parser.add_argument('--resume-step', action='store_true')
    parser.add_argument('--seed', type=int, default=123)
    parser.add_argument('--encoder', type=str, choices=['resnet50', 'resnet101'], default='resnet50')
    parser.add_argument('--log-step', type=int, default=10)
    parser.add_argument('--save-step', type=int, default=4750)
    parser.add_argument('--matching', type=str, choices=['conv', 'cosine'], default='conv')
    parser.add_argument('--self-structure', type=str, choices=['cluster', 'basic'], default=None)
    parser.add_argument('--region-conv', action='store_true')
    parser.add_argument('--keep-topk', type=int, default=32)
    parser.add_argument('--no-pixel', action='store_false', dest='pixel')
    parser.add_argument('--average', action='store_true')
    parser.add_argument('--input-height', type=int, default=512)
    parser.add_argument('--input-width', type=int, default=512)
    # parser.add_argument('--no-crop', action='store_false', dest='crop')
    parser.add_argument('--no-decoder', action='store_false', dest='decoder')
    parser.add_argument('--fuse-mode', type=str, choices=['concat', 'region-attn', 'pixel-attn'], default='concat')
    parser.add_argument('--final-mask', action='store_true')
    parser.add_argument('--noise', action='store_true')

    # learning rate
    parser.add_argument('--base-lr', type=float, default=1e-5)
    parser.add_argument('--encoder-lr-weight', type=float, default=1.0)
    parser.add_argument('--lr-decay-step', type=int, default=9501)
    parser.add_argument('--lr-decay-rate', type=float, default=0.9)

    # augmentation
    parser.add_argument('--flip-rate', type=float, default=0.5)
    parser.add_argument('--blur-rate', type=float, default=1.0)
    parser.add_argument('--blur-mode', type=str, choices=['edge', 'body'], default='body')
    parser.add_argument('--rotation', type=int, default=45)
    parser.add_argument('--min-margin', type=float, default=0.0)
    parser.add_argument('--max-margin', type=float, default=1.0)
    parser.add_argument('--fix-margin', type=float, default=0.5)

    # output
    parser.add_argument('--model-dir', type=str, default='../models/model')
    parser.add_argument('--save-dir', type=str, default=None)

    # dataset
    parser.add_argument('--split-train', type=str, nargs='+', default=['../splits/split_davis2017_train.json'])
    parser.add_argument('--split-val', type=str, default='../splits/split_davis2017_val.json')

    args = parser.parse_args()
    return args
