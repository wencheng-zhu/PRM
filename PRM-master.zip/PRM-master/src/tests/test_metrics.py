import numpy as np
import random
import metrics


def test_jaccard():
    mask_a = [1, 0, 0, 1]
    mask_b = np.array([1, 1, 0, 0])
    answer = 1 / 3
    output = metrics.jaccard(mask_a, mask_b)
    assert np.isclose(output, answer)
    assert type(output) == float

    mask_a = np.array([[0, 0], [0, 0]])
    mask_b = np.array([[0, 0], [0, 0]])
    answer = 1
    output = metrics.jaccard(mask_a, mask_b)
    assert np.isclose(output, answer)
    assert type(output) == float


def test_average_meter():
    values = [random.randint(0, 100) for _ in range(100)]

    avg_meter = metrics.AverageMeter()
    for value in values:
        avg_meter.update(value)

    answer = sum(values) / 100
    output = avg_meter.mean()
    assert answer == output
