import unittest
from unittest import mock
from dataloader import dataset
import numpy as np
from torch.utils.data import DataLoader


def mock_open_image_rgb(*args, **kwargs):
    image = np.zeros((128, 128, 3), dtype=np.uint8)
    image[32:64, 32:64] = 255
    return image


def mock_open_image_gray(*args, **kwargs):
    image = np.zeros((128, 128), dtype=np.uint8)
    image[32:64, 32:64] = 255
    return image


@mock.patch.object(dataset.Image, "open", mock_open_image_rgb)
class TestDataset(unittest.TestCase):
    def setUp(self):
        self.sequence = [{
            "image_path": "dummy",
            "mask_path": "dummy",
            "video_name": "dummy",
            "num_frames": 8,
            "frame_index": i % 8,
            "object_index": 255
        } for i in range(16)]

    def test_train_dataset(self):
        batch_size = 4
        h = 128
        w = 128
        train_set = dataset.TrainDataset(self.sequence, h, w, 0.5, 1.5, 0.5, 45, 0.5, "body", False)
        loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)

        for image_ref, mask_ref, image_cur, mask_cur, mask_prev, crop_box in loader:
            assert image_ref.shape == (batch_size, 3, h, w)
            assert mask_ref.shape == (batch_size, 1, h, w)
            assert image_cur.shape == (batch_size, 3, h, w)
            assert mask_cur.shape == (batch_size, 1, h, w)
            assert mask_prev.shape == (batch_size, 1, h, w)
            assert crop_box.shape == (batch_size, 4)

    def test_test_dataset(self):
        batch_size = 1
        h = 128
        w = 128
        test_set = dataset.TestDataset(self.sequence, h, w, 0.5)
        loader = DataLoader(test_set, batch_size=batch_size, shuffle=False)

        for image_ref, mask_ref, image_cur, mask_cur, mask_prev, crop_box in loader:
            assert image_ref.shape == (batch_size, 3, h, w)
            assert mask_ref.shape == (batch_size, 1, h, w)
            assert image_cur.shape == (batch_size, 3, h, w)
            assert mask_cur.shape == (batch_size, 1, h, w)
            assert mask_prev.shape == (batch_size, 1, h, w)
            assert crop_box.shape == (batch_size, 4)

            test_set.mask_prev = mock_open_image_gray()
