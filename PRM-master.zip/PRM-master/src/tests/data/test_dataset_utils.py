import numpy as np
import random
from dataloader import dataset_utils


def test_crop_array():
    array = [1, 2, 3, 4, 5]

    output = dataset_utils.crop_array(array, 2, 9, 0, -1)
    answer = [3, 4, 5, -1, -1, -1, -1]
    assert np.isclose(output, answer).all()

    output = dataset_utils.crop_array(array, -3, 2, 0)
    answer = [0, 0, 0, 1, 2]
    assert np.isclose(output, answer).all()

    array = [[1, 2, 3],
             [4, 5, 6],
             [7, 8, 9]]
    output = dataset_utils.crop_array(array, -2, 2, 1, -1)
    answer = [[-1, -1, 1, 2],
              [-1, -1, 4, 5],
              [-1, -1, 7, 8]]
    assert np.isclose(output, answer).all()


def test_crop_image():
    def _test(image, x1, y1, x2, y2):

        output = dataset_utils.crop_image(image, [x1, y1, x2, y2])
        answer = dataset_utils.crop_array(image, y1, y2, dim=0)
        answer = dataset_utils.crop_array(answer, x1, x2, dim=1)

        assert np.isclose(output, answer).all()

    image = np.random.random((9, 16, 3))

    x1, y1, x2, y2 = 2, 3, 12, 8
    _test(image, x1, y1, x2, y2)

    x1, y1, x2, y2 = 5, 3, 24, 18
    _test(image, x1, y1, x2, y2)


def test_crop_image_back():
    image = np.random.random((9, 16, 3))
    x1, y1, x2, y2 = 2, 3, 12, 8

    cropped = dataset_utils.crop_image(image, [x1, y1, x2, y2])
    output = dataset_utils.crop_image_back(cropped, [x1, y1, x2, y2], image.shape[0], image.shape[1])

    assert output.shape == image.shape
    assert np.isclose(output[y1:y2, x1:x2, :], image[y1:y2, x1:x2, :]).all()
    output[y1:y2, x1:x2, :] = 0
    assert np.isclose(output, 0).all()
