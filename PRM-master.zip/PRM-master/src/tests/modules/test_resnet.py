import torch
from torch.nn import functional as F
from modules import resnet
import pytest


class TestResNet():
    def setup(self):
        self.height = 32
        self.width = 32
        self.batch_size = 2
        self.inputs = torch.randn(self.batch_size, 4, self.height, self.width)

    def test_resnet50(self):
        model = resnet.resnet50(pretrained=True)
        output = model(self.inputs)
        assert [x.shape for x in output] == [
            (self.batch_size, 2048, self.height // 32, self.width // 32),
            (self.batch_size, 1024, self.height // 16, self.width // 16),
            (self.batch_size, 512, self.height // 8, self.width // 8),
            (self.batch_size, 256, self.height // 4, self.width // 4),
            (self.batch_size, 64, self.height // 2, self.width // 2)
        ]

    def test_resnet101(self):
        resnet.resnet101(pretrained=True)

    def test_resnet50_deeplabv3(self):
        with pytest.raises(NotImplementedError):
            resnet.resnet50_deeplabv3(pretrained=True)

        model = resnet.resnet50_deeplabv3(pretrained=False)
        output = model(self.inputs)
        assert [x.shape for x in output] == [
            (self.batch_size, 2048, self.height // 8, self.width // 8),
            (self.batch_size, 1024, self.height // 8, self.width // 8),
            (self.batch_size, 512, self.height // 8, self.width // 8),
            (self.batch_size, 256, self.height // 4, self.width // 4),
            (self.batch_size, 64, self.height // 2, self.width // 2)
        ]

    def test_resnet101_deeplabv3(self):
        resnet.resnet101_deeplabv3(pretrained=True)
