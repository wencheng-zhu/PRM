import torch
from torch.nn import functional as F
from modules import regionwise


def test_depth_corr():

    def _brute_force(inputs, kernel):
        batch_size, channels, h_inputs, w_inputs = inputs.shape
        _, _, h_kernel, w_kernel = kernel.shape
        
        inputs = inputs.view(batch_size * channels, 1, h_inputs, w_inputs)
        kernel = kernel.view(batch_size * channels, 1, h_kernel, w_kernel)

        answer = torch.zeros(batch_size * channels, h_inputs, w_inputs)

        for map_idx in range(batch_size * channels):
            inputs_map = inputs[map_idx:map_idx + 1]
            kernel_map = kernel[map_idx:map_idx + 1]
            corr_map = F.conv2d(inputs_map, kernel_map, padding=(h_kernel // 2, w_kernel // 2))
            answer[map_idx, :, :] = corr_map[0, 0]

        answer = answer.view(batch_size, channels, h_inputs, w_inputs)
        return answer            
            
    depth_corr = regionwise.DepthCorr()

    kernel = torch.randn(2, 3, 1, 1)
    inputs = torch.randn(2, 3, 4, 4)
    output = depth_corr(inputs, kernel)
    answer = _brute_force(inputs, kernel)
    assert torch.isclose(output, answer).all()

    kernel = torch.randn(2, 3, 5, 3)
    inputs = torch.randn(2, 3, 9, 9)
    output = depth_corr(inputs, kernel)
    answer = _brute_force(inputs, kernel)
    assert torch.isclose(output, answer).all()


def test_region_kernel_conv():
    model = regionwise.RegionKernelConv(channels=3, kernel_size=(7, 7))
    features_ref = torch.randn(2, 3, 7, 7)
    features_cur = torch.randn(2, 3, 16, 16)
    output = model(features_ref, features_cur)
    # TODO: finish test
    assert output.shape == features_cur.shape
