import torch
from torch.nn import functional as F
from modules import pixelwise


class TestPixelCorr():

    def setup(self):
        self.feat_ref_irregular = torch.randn(2, 5, 3, 7)
        self.feat_cur_irregular = torch.randn(2, 5, 4, 6)
        self.feat_ref_regular = torch.randn(4, 7, 3, 3)
        self.feat_cur_regular = torch.randn(4, 7, 5, 5)

    def test_corr_cosine(self):

        def _brute_force(features_ref, features_cur):
            b, c, h_ref, w_ref = features_ref.shape
            _, _, h_cur, w_cur = features_cur.shape

            features_ref = features_ref.view(b, c, 1, -1)
            features_cur = features_cur.view(b, c, -1, 1)

            answer = F.cosine_similarity(features_cur, features_ref)
            answer = answer.view(b, h_cur, w_cur, h_ref, w_ref)
            return answer

        corr_cosine = pixelwise.CorrCosine()

        output = corr_cosine(self.feat_ref_regular, self.feat_cur_regular)
        answer = _brute_force(self.feat_ref_regular, self.feat_cur_regular)
        assert torch.isclose(output, answer, atol=1e-6).all()

        output = corr_cosine(self.feat_ref_irregular, self.feat_cur_irregular)
        answer = _brute_force(self.feat_ref_irregular, self.feat_cur_irregular)
        assert torch.isclose(output, answer, atol=1e-6).all()

    def test_corr_conv(self):

        def _brute_force(features_ref, features_cur):
            batch_size, channels, h_ref, w_ref = features_ref.shape
            _, _, h_cur, w_cur = features_cur.shape

            answer = torch.zeros(batch_size, h_cur * w_cur, h_ref * w_ref)

            for batch in range(batch_size):
                feat_ref = features_ref[batch].view(channels, h_ref * w_ref)
                feat_cur = features_cur[batch].view(channels, h_cur * w_cur)
                
                for ref_idx in range(feat_ref.shape[1]):
                    ref_pixel = feat_ref[:, ref_idx:ref_idx + 1]
                    corr_ref_pixel = torch.sum(ref_pixel * feat_cur, dim=0)
                    answer[batch, :, ref_idx] = corr_ref_pixel

            answer = answer.view(batch_size, h_cur, w_cur, h_ref, w_ref)
            return answer

        corr_conv = pixelwise.CorrConv()

        output = corr_conv(self.feat_ref_regular, self.feat_cur_regular)
        answer = _brute_force(self.feat_ref_regular, self.feat_cur_regular)
        assert torch.isclose(output, answer, atol=1e-6).all()

        output = corr_conv(self.feat_ref_irregular, self.feat_cur_irregular)
        answer = _brute_force(self.feat_ref_irregular, self.feat_cur_irregular)
        assert torch.isclose(output, answer, atol=1e-6).all()


def test_self_structure():
    corr_features = torch.randn(2, 8, 8, 8, 8)
    features_ref = torch.randn(2, 1024, 8, 8)
    mask_ref = (torch.randn(2, 1, 200, 200) > 0).type(torch.float32)
    keep_topk = 16

    model = pixelwise.SelfStructure(keep_topk, 'cluster')
    struct_info = model(corr_features, features_ref, mask_ref)
    assert struct_info.shape == (2, keep_topk * 2, 8, 8)

    model = pixelwise.SelfStructure(keep_topk, 'basic')
    struct_info = model(corr_features, features_ref, mask_ref)
    assert struct_info.shape == (2, 8 * 8, 8, 8)
