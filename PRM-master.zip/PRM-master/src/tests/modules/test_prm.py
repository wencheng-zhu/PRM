import torch
from torch.nn import functional as F
from modules import prm


def test_pixel_region_corr():
    pixel_corr = torch.randn(2, 64, 16, 16)
    region_corr = torch.randn(2, 128, 16, 16)

    model = prm.PixelRegionCorr('concat', 64, 64, 128, 32)
    output = model(pixel_corr, region_corr)
    assert output.shape == (2, 96, 16, 16)

    model = prm.PixelRegionCorr('region-attn', 64, 48, 128, 48)
    output = model(pixel_corr, region_corr)
    assert output.shape == (2, 48, 16, 16)

    model = prm.PixelRegionCorr('pixel-attn', 64, 64, 128, 128)
    output = model(pixel_corr, region_corr)
    assert output.shape == (2, 128, 16, 16)


def test_prnet():
    batch_size = 3
    h_cur = 200
    w_cur = 200
    h_ref = 200
    w_ref = 200
    image_ref = torch.randn(batch_size, 3, h_ref, w_ref)
    mask_ref = (torch.randn(batch_size, 1, h_ref, w_ref) > 0).type(torch.float32)
    image_cur = torch.randn(batch_size, 3, h_cur, w_cur)
    mask_cur = (torch.randn(batch_size, 1, h_cur, w_cur) > 0).type(torch.float32)

    model = prm.PRNet(encoder='resnet50', matching='conv', keep_topk=32, pixel_corr=True, average=False, decoder=True, 
                      self_structure='cluster', region_conv=False, fuse_mode='concat', final_mask=False)
    output = model(image_ref, mask_ref, image_cur, mask_cur)
    assert output.shape == (batch_size, 2, h_cur, w_cur)
    assert output.dtype == torch.float32
    assert model.pixel_corr.self_structure is not None

    model = prm.PRNet(encoder='resnet50', matching='cosine', keep_topk=16, pixel_corr=True, average=False, decoder=True, 
                      self_structure='basic', region_conv=True, fuse_mode='region-attn', final_mask=True)
    output = model(image_ref, mask_ref, image_cur, mask_cur)
    assert output.shape == (batch_size, 2, h_cur, w_cur)
    assert output.dtype == torch.float32
    assert model.pixel_corr.self_structure is not None

    model = prm.PRNet(encoder='resnet50', matching='cosine', keep_topk=16, pixel_corr=False, average=False, decoder=True, 
                      self_structure=None, region_conv=True, fuse_mode='concat', final_mask=False)
    output = model(image_ref, mask_ref, image_cur, mask_cur)
    assert output.shape == (batch_size, 2, h_cur, w_cur)

    model = prm.PRNet(encoder='resnet50', matching='cosine', keep_topk=16, pixel_corr=True, average=False, decoder=True, 
                      self_structure=None, region_conv=False, fuse_mode='concat', final_mask=True)
    output = model(image_ref, mask_ref, image_cur, mask_cur)
    assert output.shape == (batch_size, 2, h_cur, w_cur)
