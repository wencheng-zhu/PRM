import unittest
from unittest import mock
import train
import init_helper
import argparse


class MockArgumentParser(object):
    def __init__(self):
        self.parser = argparse.ArgumentParser()

    def add_argument(self, *args, **kwargs):
        self.parser.add_argument(*args, **kwargs)

    def parse_args(self):
        self.parser.parse_args([''])


@mock.patch.object(argparse, 'ArgumentParser', MockArgumentParser)
class TestTrain(unittest.TestCase):
    def test_train(self):
        train.main()
