import json
import logging
import os
import time

import cv2
import numpy as np
import torch
import torch.nn.functional as F
import torch.utils.data as data
from torchvision import transforms

import init_helper
import metrics
from dataloader import dataset_utils
from dataloader.dataset import TestDataset
from modules.prm import PRNet

logger = logging.getLogger()


def evaluate(model, loader, log_step, visualize=False, save_dir=None, compute_jaccard=True):
    jaccards = metrics.AverageMeter()
    spents = metrics.AverageMeter()

    model = model.eval()

    features_ref = None

    with torch.no_grad():

        for batch_idx, (image_ref, mask_ref, image_cur, _, mask_prev, crop_box) in enumerate(loader):
            frame_info = loader.dataset.sequence[batch_idx]

            crop_box = crop_box[0]
            x1, y1, x2, y2 = crop_box
            box_width = x2 - x1
            box_height = y2 - y1

            image_ref = image_ref.cuda()
            image_cur = image_cur.cuda()
            mask_ref = mask_ref.cuda()
            mask_prev = mask_prev.cuda()

            start = time.time()

            if frame_info["frame_index"] == 0:
                image_mask_ref = torch.cat([image_ref, mask_ref], dim=1)
                features_ref = model.encoder(image_mask_ref)

            pred_mask = model(image_ref, mask_ref, image_cur, mask_prev, features_ref)

            pred_mask = torch.softmax(pred_mask, dim=1)

            # pred_mask_vs = (torch.argmax(pred_mask.clone(), dim=1) * 255).type(torch.uint8).squeeze().cpu().numpy()

            pred_mask = F.interpolate(pred_mask, (box_height, box_width), mode="bilinear")

            org_mask_cur = loader.dataset.get_mask(batch_idx)
            org_height, org_width = org_mask_cur.shape

            pred_mask = pred_mask.cpu().numpy().squeeze(0).transpose(1, 2, 0)
            pred_mask = dataset_utils.crop_image_back(pred_mask, crop_box, org_height, org_width)

            spent = time.time() - start
            spents.update(spent)

            if save_dir is not None:
                video_dir = os.path.join(save_dir, frame_info["video_name"], str(frame_info["object_index"]))
                os.makedirs(video_dir, exist_ok=True)
                basename, _ = os.path.splitext(os.path.basename(frame_info["image_path"]))
                if frame_info["frame_index"] == 0:
                    save_mask = loader.dataset.get_mask(batch_idx)
                else:
                    save_mask = pred_mask[:, :, 1]
                cv2.imwrite(os.path.join(video_dir, f"{basename}.png"), save_mask * 255)

                # color_map_dir = os.path.join("../../corr/davis16", frame_info["video_name"], str(frame_info["object_index"]))

                # inv_normalize = transforms.Normalize(
                #     mean=[-0.485/0.229, -0.456/0.224, -0.406/0.225],
                #     std=[1/0.229, 1/0.224, 1/0.225]
                # )

                # cv2.imwrite(os.path.join(color_map_dir, "{}_pred.png".format(basename)), pred_mask_vs)
                # cv2.imwrite(os.path.join(color_map_dir, "{}_gt.png".format(basename)), mask_cur.squeeze().cpu().numpy())

                # image_cur_vs = inv_normalize(image_cur.squeeze(0).cpu())
                # image_cur_vs = (image_cur_vs * 255).permute(1, 2, 0).numpy().astype(np.uint8)
                # image_cur_vs = cv2.cvtColor(image_cur_vs, cv2.COLOR_RGB2BGR)
                # cv2.imwrite(os.path.join(color_map_dir, "{}_cur.jpg".format(basename)), image_cur_vs)

                # image_ref_vs = inv_normalize(image_ref.squeeze(0).cpu())
                # image_ref_vs = (image_ref_vs * 255).permute(1, 2, 0).numpy().astype(np.uint8)
                # image_ref_vs = cv2.cvtColor(image_ref_vs, cv2.COLOR_RGB2BGR)
                # cv2.imwrite(os.path.join(color_map_dir, "{}_ref.jpg".format(basename)), image_ref_vs)

                # color_maps = np.concatenate([vs_pixel_maps, vs_region_maps, vs_corr_maps], axis=-1)

                # for i in range(color_maps.shape[-1]):
                #     color_map = color_maps[:, :, i]
                #     color_map -= color_map.min()
                #     color_map /= color_map.max() + 1e-6
                #     color_map = cv2.resize(color_map, (256, 256), interpolation=cv2.INTER_LINEAR)
                #     color_map = (color_map * 255).astype(np.uint8)
                #     # color_map = cv2.applyColorMap(color_map, cv2.COLORMAP_JET)
                #     # color_map = cv2.cvtColor(color_map, cv2.COLOR_RGB2BGR)
                #     # color_map = cv2.vconcat([cv2.hconcat(color_maps[i: i+8]) for i in range(0, 64, 8)])
                    
                #     # cv2.imshow("color_map", color_map)
                #     # cv2.waitKey(1)
                #     os.makedirs(color_map_dir, exist_ok=True)
                #     cv2.imwrite(os.path.join(color_map_dir, "{}_{}.png".format(basename, i)), color_map)

            if frame_info["frame_index"] == 0:
                pred_mask = loader.dataset.get_mask(batch_idx)
            else:
                pred_mask = np.argmax(pred_mask, axis=-1).astype(np.float32)

            loader.dataset.mask_prev = pred_mask

            jaccard = metrics.jaccard(org_mask_cur, pred_mask) if compute_jaccard else -1
            jaccards.update(jaccard)

            if visualize:
                cv2.imshow("img_ref", image_ref.squeeze().cpu().numpy().transpose(1, 2, 0))
                cv2.imshow("img_cur", image_cur.squeeze().cpu().numpy().transpose(1, 2, 0))
                cv2.imshow("mask_prev", mask_prev.squeeze().cpu().numpy())
                # cv2.imshow("org_img_cur", org_image_cur)
                # cv2.imshow("org_mask_cur", org_mask_cur)
                cv2.imshow("pred_mask", pred_mask.astype(np.float32))
                cv2.waitKey(1)

            if (batch_idx + 1) % log_step == 0:
                logger.info(f"iter {batch_idx}: jaccard: {jaccard:.4f} time: {spent:.4f}")

    return jaccards.mean(), spents.mean()


def main():
    args = init_helper.get_arguments()

    init_helper.init_logger(os.path.join(args.model_dir, "logs"), f"{os.path.basename(args.resume)}.log")
    init_helper.set_random_seed(args.seed)

    checkpoint = torch.load(args.resume, map_location=lambda storage, location: storage)
    model_dict = checkpoint["model_dict"]
    model = PRNet(args.encoder, args.matching, args.keep_topk, args.pixel, args.average, args.decoder,
                  args.self_structure, args.region_conv, args.fuse_mode, args.final_mask).cuda()
    model = model.eval()
    model.load_state_dict(model_dict)

    logger.info(args)

    with open(args.split_val, "r") as f:
        sequence = json.load(f)

    dataset = TestDataset(sequence, args.input_height, args.input_width, args.fix_margin)

    loader = data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    jaccard, time_elapsed = evaluate(model, loader, args.log_step, visualize=args.visualize,
                                     save_dir=args.save_dir, compute_jaccard=True)
    logger.info(f"jaccard: {jaccard:.4f} time elapsed: {time_elapsed:.4f}")


if __name__ == "__main__":
    main()
