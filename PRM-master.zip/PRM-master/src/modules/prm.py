import torch
from torch import nn
import torch.nn.functional as F
import math

from modules import resnet, pixelwise, regionwise


class ResidualBlock(nn.Module):
    def __init__(self, v):
        super().__init__()
        self.res = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Conv2d(v, v, kernel_size=3, padding=1, bias=True), 
            nn.ReLU(inplace=True),
            nn.Conv2d(v, v, kernel_size=3, padding=1, bias=True)
        )

    def forward(self, x):
        x = x + self.res(x)
        return x


class GlobalConvolutionBlock(nn.Module):
    def __init__(self, in_dim, out_dim=256, k=7):
        super().__init__()
        self.branch1 = nn.Sequential(
            nn.Conv2d(in_dim, out_dim, kernel_size=(1,k), padding=(0, k//2), bias=True), 
            nn.Conv2d(out_dim, out_dim, kernel_size=(k,1), padding=(k//2, 0), bias=True)
        )

        self.branch2 = nn.Sequential(
            nn.Conv2d(in_dim, out_dim, kernel_size=(k,1), padding=(0, k//2), bias=True), 
            nn.Conv2d(out_dim, out_dim, kernel_size=(1,k), padding=(k//2, 0), bias=True)
        )

        self.RB = ResidualBlock(out_dim)

    def forward(self, x):
        out = self.branch1(x) + self.branch2(x)
        out = self.RB(out)
        return out


class RefinementModule(nn.Module):
    def __init__(self, in_dim, out_dim=256):
        super().__init__()
        self.conv = nn.Conv2d(in_dim, out_dim, kernel_size=3, padding=1, dilation=1, bias=True)
        self.RB1 = ResidualBlock(out_dim)
        self.RB2 = ResidualBlock(out_dim)

    def forward(self, x_top, x_low):
        _, _, h, w = x_low.size()

        x_top = F.interpolate(x_top, size=(h, w), mode='bilinear')
        x_low = self.RB1(self.conv(x_low))
        x = x_top + x_low
        x = self.RB2(x)
        return x


class PixelRegionCorr(nn.Module):
    def __init__(self, fuse_mode, pixel_in_channels, pixel_default_out_channels, region_in_channels, region_default_out_channels):
        super().__init__()
        assert fuse_mode in ['concat', 'pixel-attn', 'region-attn']
        self.fuse_mode = fuse_mode

        self.pixel_conv1x1 = None
        self.region_conv1x1 = None

        # init as concat fuse mode
        self.out_channels = pixel_default_out_channels + region_default_out_channels
        pixel_out_channels = pixel_default_out_channels
        region_out_channels = region_default_out_channels

        if fuse_mode == 'region-attn':
            region_out_channels = 1
            self.out_channels = pixel_out_channels
        elif fuse_mode == 'pixel-attn':
            pixel_out_channels = 1
            self.out_channels = region_out_channels

        if pixel_in_channels != pixel_out_channels:
            self.pixel_conv1x1 = nn.Conv2d(pixel_in_channels, pixel_out_channels, (1, 1))

        if region_in_channels != region_out_channels:
            self.region_conv1x1 = nn.Conv2d(region_in_channels, region_out_channels, (1, 1))

    def forward(self, pixel_corr, region_corr):
        if self.pixel_conv1x1:
            pixel_corr = self.pixel_conv1x1(pixel_corr)

        if self.region_conv1x1:
            region_corr = self.region_conv1x1(region_corr)

        if self.fuse_mode == 'concat':
            corr = torch.cat([pixel_corr, region_corr], dim=1)
        else:
            corr = pixel_corr * region_corr

        return corr


class PRNet(nn.Module):

    def __init__(self, encoder, matching, keep_topk, pixel_corr, average, decoder, self_structure, region_conv, fuse_mode, final_mask):
        super().__init__()
        self.final_mask = final_mask
        self.decoder = decoder

        Encoder = {'resnet50': resnet.resnet50, 'resnet101': resnet.resnet101}[encoder]
        self.encoder = Encoder(pretrained=True)

        if pixel_corr:
            self.pixel_corr = pixelwise.PixelSimilarity(matching, keep_topk, average, self_structure)
            pixel_channels = self.pixel_corr.out_channels
        else:
            self.pixel_corr = None
            pixel_channels = 0

        if region_conv:
            self.region_conv = regionwise.RegionKernelConv()
            region_in_channels = self.region_conv.out_channels
            region_out_channels = keep_topk
        else:
            self.region_conv = None
            region_in_channels = 0
            region_out_channels = 0

        self.pixel_region_corr = PixelRegionCorr(fuse_mode, pixel_channels, pixel_channels,
                                                 region_in_channels, region_out_channels)

        self.GCB = GlobalConvolutionBlock(4096)
        self.RM1 = RefinementModule(1024 + self.pixel_region_corr.out_channels)
        self.RM2 = RefinementModule(512 + self.pixel_region_corr.out_channels)
        self.RM3 = RefinementModule(256 + self.pixel_region_corr.out_channels)

        classifier_in_channels = 257 if final_mask else 256
        self.classifier = nn.Conv2d(classifier_in_channels, 2, kernel_size=3, padding=1)
        self.dropout2d = nn.Dropout2d(p=0.5)

    def forward(self, image_ref, mask_ref, image_cur, mask_prev, features_ref=None):

        _, _, height_cur, width_cur = image_cur.shape

        if features_ref is None:
            image_mask_ref = torch.cat([image_ref, mask_ref], dim=1)
            ref_x5, ref_x4, _, _, _ = self.encoder(image_mask_ref)
        else:
            ref_x5, ref_x4, _, _, _ = features_ref

        image_mask_cur = torch.cat([image_cur, mask_prev], dim=1)
        cur_x5, cur_x4, cur_x3, cur_x2, _ = self.encoder(image_mask_cur)

        ref_x5 = F.interpolate(ref_x5, cur_x5.shape[-2:], mode='bilinear')
        x = torch.cat([ref_x5, cur_x5], dim=1) # b, 4096, 8, 8

        x = self.GCB(x) # 8, 256, 8, 8

        if self.pixel_corr:
            pixel_map = self.pixel_corr(ref_x4, cur_x4, mask_ref)
        else:
            pixel_map = torch.zeros(cur_x4.shape[0], 0, cur_x4.shape[2], cur_x4.shape[3], device=cur_x4.device)

        if self.region_conv:
            region_map = self.region_conv(ref_x4, cur_x4)
        else:
            region_map = torch.zeros(cur_x4.shape[0], 0, cur_x4.shape[2], cur_x4.shape[3], device=cur_x4.device)

        corr_maps = self.pixel_region_corr(pixel_map, region_map)

        # vs_pixel_maps = pixel_map.clone().squeeze(0).permute(1, 2, 0).cpu().numpy()
        # vs_region_maps = region_map.clone().squeeze(0).permute(1, 2, 0).cpu().numpy()
        # vs_corr_maps = corr_maps.clone().squeeze(0).permute(1, 2, 0).cpu().numpy()

        cur_x4 = torch.cat([cur_x4, corr_maps], dim=1)

        corr_maps = F.interpolate(corr_maps, cur_x3.shape[-2:], mode='nearest')
        cur_x3 = torch.cat([cur_x3, corr_maps], dim=1)

        corr_maps = F.interpolate(corr_maps, cur_x2.shape[-2:], mode='nearest')
        cur_x2 = torch.cat([cur_x2, corr_maps], dim=1)

        if self.decoder:
            x = self.RM1(x, cur_x4)   # 8, 256, 16, 16
            x = self.RM2(x, cur_x3)   # 8, 256, 32, 32
            x = self.RM3(x, cur_x2)   # 8, 256, 64, 64

            x = self.dropout2d(x)
            
            if self.final_mask:
                mask_prev_cat = F.interpolate(mask_prev, x.shape[-2:], mode='nearest')
                x = torch.cat([x, mask_prev_cat], dim=1)

            x = self.classifier(x)   # 8, 2, 64, 64
        else:
            # keep topk must be set to 1
            x = corr_maps

        out = F.interpolate(x, size=(height_cur, width_cur), mode='bilinear') # 8, 2, 256, 256

        return out#, vs_pixel_maps, vs_region_maps, vs_corr_maps
