import torch
from torch import nn
from torch.nn import functional as F
import math


class CorrCosine(nn.Module):
    def __init__(self):
        super().__init__()
        self.corr_conv = CorrConv()

    def forward(self, features_ref, features_cur):
        """
        Soft matching layer.
        :param features_ref: shape [batch, channels, height, width]
        :param features_cur: shape [batch, channels, height, width]
        :return:
        """
        features_ref = F.normalize(features_ref, p=2, dim=1)
        features_cur = F.normalize(features_cur, p=2, dim=1)
        sim_matrix = self.corr_conv(features_ref, features_cur)
        return sim_matrix


class CorrConv(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, features_ref, features_cur):
        """
        correlation module
        :param features_ref: shape [batch, channels, height_ref, width_ref]
        :param features_cur: shape [batch, channels, height_cur, width_cur]
        :return:
        """
        batch_size, num_channels, height_ref, width_ref = features_ref.shape
        _, _, height_cur, width_cur = features_cur.shape
        features_cur = features_cur.permute(0, 2, 3, 1).contiguous().view(batch_size * height_cur * width_cur, num_channels, 1, 1)
        features_ref = features_ref.view(1, batch_size * num_channels, height_ref, width_ref)
        corr_features = F.conv2d(features_ref, features_cur, groups=batch_size)
        corr_features = corr_features.view(batch_size, height_cur, width_cur, height_ref, width_ref)

        return corr_features


class ScaledDotProductAttention(nn.Module):
    def __init__(self, drop_rate=0.5):
        super().__init__()
        self.dropout = nn.Dropout(drop_rate)

    def forward(self, Q, K, V):
        attn = torch.bmm(Q, K.transpose(2, 1))
        attn = attn / math.sqrt(K.shape[-1])

        attn = torch.softmax(attn, dim=-1)
        attn = self.dropout(attn)
        out = torch.bmm(attn, V)

        return out, attn


class SelfStructure(nn.Module):
    def __init__(self, keep_topk, self_structure):
        super().__init__()
        assert self_structure in ['cluster', 'basic']
        self.keep_topk = keep_topk
        self.cluster = (self_structure == 'cluster')
        self.attention = ScaledDotProductAttention()
        # self.conv = nn.Conv2d(1024, keep_topk * 2, (1, 1))

    def forward(self, corr_features, features_cur, mask_ref):
        # top k pixels in current frame that match one pixel in reference frame
        batch_size, height_cur, width_cur, height_ref, width_ref = corr_features.shape
        _, channels, _, _ = features_cur.shape
        features_cur = features_cur.view(batch_size, channels, height_cur * width_cur)

        if self.cluster:
            corr_features = corr_features.view(batch_size, height_cur * width_cur, height_ref * width_ref)

            mask_ref = F.interpolate(mask_ref, (height_ref, width_ref), mode='bilinear')
            mask_ref = mask_ref.view(batch_size, 1, height_ref * width_ref)
            fg_corr = corr_features * (mask_ref > 0.5).type(torch.float32)
            bg_corr = corr_features * (mask_ref <= 0.5).type(torch.float32)

            fg_struct = self.get_struct_info(fg_corr, features_cur)
            bg_struct = self.get_struct_info(bg_corr, features_cur)
            struct_info = torch.cat([bg_struct, fg_struct], dim=1)
        else:
            struct_info = features_cur.transpose(2, 1)

        struct_info = torch.bmm(struct_info, features_cur)
        num_points = struct_info.shape[1]
        struct_info = struct_info.view(batch_size, num_points, height_cur, width_cur)
        # struct_info, _ = self.attention(features_cur.transpose(2, 1), struct_info, struct_info)
        # struct_info = struct_info.transpose(2, 1).view(batch_size, channels, height_cur, width_cur)
        # struct_info = self.conv(struct_info)        
        # group conv
        features_cur = features_cur.view(batch_size, channels, height_cur, width_cur)
        struct_info = struct_info.repeat(1, channels // num_points, 1, 1)
        struct_info *= features_cur
        struct_info = struct_info.view(batch_size, channels // num_points, num_points, height_cur, width_cur).sum(2)
        return struct_info

    def get_struct_info(self, corr, features_cur):
        batch_size = features_cur.shape[0]
        corr = torch.sum(corr, dim=-1)
        _, topk_indices = torch.topk(corr, self.keep_topk, dim=1)
        struct_info = features_cur[[[b] for b in range(batch_size)], :, topk_indices]   # sized [b, k, c]
        return struct_info


class PixelSimilarity(nn.Module):
    def __init__(self, matching, keep_topk, average, self_structure):
        super().__init__()
        self.out_channels = 2 * keep_topk
        if self_structure:
            self.out_channels += 1024 // (2 * keep_topk)
        self.soft_matching = {'conv': CorrConv, 'cosine': CorrCosine}[matching]()
        self.mask_topk = MaskedTopk(keep_topk, average)
        self.self_structure = SelfStructure(keep_topk, self_structure) if self_structure else None

    def forward(self, features_ref, features_cur, mask_ref):
        corr_features = self.soft_matching(features_ref, features_cur)
        pixel_corr = self.mask_topk(corr_features, mask_ref)
        if self.self_structure:
            struct_corr = self.self_structure(corr_features, features_ref, mask_ref)
            pixel_corr = torch.cat([pixel_corr, struct_corr], dim=1)
        return pixel_corr


class MaskedTopk(nn.Module):
    def __init__(self, keep_topk, average):
        super().__init__()
        self.keep_topk = keep_topk
        self.average = average

    def forward(self, corr_features, mask_ref):
        """
        :param corr_features: [batch_size, height_cur, width_cur, height_ref, width_ref]
        :param mask_ref: byte tensor of shape [batch, 1, height, width]
        :param keep_topk: preferably 20
        """
        batch_size, height_cur, width_cur, height_ref, width_ref = corr_features.shape
        corr_features = corr_features.view(batch_size, height_cur * width_cur, height_ref * width_ref)
        mask_ref = F.interpolate(mask_ref, (height_ref, width_ref), mode='bilinear')
        mask_ref = mask_ref.view(batch_size, 1, height_ref * width_ref)

        fg_corr = corr_features * (mask_ref > 0.5).type(torch.float32)
        bg_corr = corr_features * (mask_ref <= 0.5).type(torch.float32)

        if self.average:
            fg_corr = torch.mean(fg_corr, dim=-1, keepdim=True)
            bg_corr = torch.mean(bg_corr, dim=-1, keepdim=True)
        else:
            fg_corr, _ = torch.topk(fg_corr, self.keep_topk, dim=-1)
            bg_corr, _ = torch.topk(bg_corr, self.keep_topk, dim=-1)

        fg_corr = fg_corr.view(batch_size, height_cur, width_cur, self.keep_topk).permute(0, 3, 1, 2)
        bg_corr = bg_corr.view(batch_size, height_cur, width_cur, self.keep_topk).permute(0, 3, 1, 2)

        corr_map = torch.cat([bg_corr, fg_corr], dim=1)

        return corr_map
