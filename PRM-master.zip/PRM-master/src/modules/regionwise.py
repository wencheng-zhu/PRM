import torch
from torch import nn
from torch.nn import functional as F


class DepthCorr(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, inputs, kernel):
        """
        :param inputs: sized [batch_size, channels, height_ref, width_ref]
        :param kernel: sized [batch_size, channels, height_cur, width_cur], where height_cur, height_width must be odd integers.
        :return: sized [batch_size, channels, height_cur, width_cur]
        """
        batch_size, channels, height_inputs, width_inputs = inputs.shape
        _, _, height_kernel, width_kernel = kernel.shape
        inputs = inputs.view(1, batch_size * channels, height_inputs, width_inputs)
        kernel = kernel.view(batch_size * channels, 1, height_kernel, width_kernel)
        corr = F.conv2d(inputs, kernel, padding=(height_kernel // 2, width_kernel // 2), groups=batch_size * channels)
        corr = corr.view(batch_size, channels, height_inputs, width_inputs)
        return corr


class RegionKernelConv(nn.Module):
    def __init__(self, channels=1024, kernel_size=(7, 7)):
        super().__init__()
        self.out_channels = channels
        self.pooling = nn.AdaptiveMaxPool2d(kernel_size)
        self.conv_in = nn.Conv2d(channels, channels, kernel_size)
        self.depth_corr = DepthCorr()

    def forward(self, features_ref, features_cur):
        kernel = self.pooling(features_ref)
        kernel = self.conv_in(kernel)
        corr_features = self.depth_corr(features_cur, kernel)
        return corr_features
