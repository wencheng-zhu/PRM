import numpy as np


def jaccard(mask_a, mask_b):
    mask_a = np.array(mask_a, dtype=np.bool)
    mask_b = np.array(mask_b, dtype=np.bool)

    if np.sum(mask_a) == 0 and np.sum(mask_b) == 0:
        return 1.0
    else:
        return float(np.sum(mask_a & mask_b) / np.sum(mask_a | mask_b))


class AverageMeter(object):
    def __init__(self, total=0, count=0):
        self.total = total
        self.count = count

    def update(self, value):
        self.total += value
        self.count += 1
    
    def mean(self):
        if self.count:
            return self.total / self.count
        else:
            return 0
