import random

import cv2
import numpy as np
import torch
import torch.utils.data as data
from PIL import Image

from dataloader import dataset_utils
from torchvision import transforms


class BaseDataset(data.Dataset):
    def __init__(self, sequence):
        self.sequence = sequence

    def __len__(self):
        return len(self.sequence)

    def get_image(self, index):
        img = np.asarray(Image.open(self.sequence[index]['image_path']))
        if img.ndim == 2:
            img = np.tile(img[:, :, None], (1, 1, 3))
        return img

    def get_mask(self, index):
        frame_info = self.sequence[index]
        mask = np.array(Image.open(frame_info['mask_path']))
        if mask.ndim == 3:
            mask = mask[:, :, 0]
        mask = (mask == frame_info['object_index']).astype(np.float32)
        return mask

    def get_image_mask(self, index):
        return self.get_image(index), self.get_mask(index)

    @property
    def image_transform(self):
        return transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

    @staticmethod
    def flip(image, mask, bounding_mask):
        image = np.flip(image, axis=1).copy()
        mask = np.flip(mask, axis=1).copy()
        bounding_mask = np.flip(bounding_mask, axis=1).copy()
        return image, mask, bounding_mask

    @staticmethod
    def rotate(image, mask, bounding_mask, degree):
        image = dataset_utils.rotate_bound(image, degree, cv2.INTER_LINEAR)
        mask = dataset_utils.rotate_bound(mask, degree, cv2.INTER_LINEAR)
        mask = (mask > 0.5).astype(np.float32)
        bounding_mask = dataset_utils.rotate_bound(bounding_mask, degree, cv2.INTER_LINEAR)
        bounding_mask = (bounding_mask > 0.5).astype(np.float32)
        return image, mask, bounding_mask

    @staticmethod
    def crop(image, mask, bounding_mask, margin_left, margin_right, margin_top, margin_bottom):
        image_height, image_width = mask.shape
        crop_box = np.array([0, 0, image_width, image_height], dtype=np.int32)

        if not np.isclose(bounding_mask, 0).all():
            x1, y1, box_width, box_height = cv2.boundingRect(bounding_mask.astype(np.uint8))
            x2 = x1 + box_width
            y2 = y1 + box_height

            x1 -= box_width * margin_left
            x2 += box_width * margin_right
            y1 -= box_height * margin_top
            y2 += box_height * margin_bottom

            if x2 - x1 > 5 and y2 - y1 > 5:
                crop_box = np.array([x1, y1, x2, y2], dtype=np.int32)

                image = dataset_utils.crop_image(image, crop_box)
                mask = dataset_utils.crop_image(mask, crop_box)
                bounding_mask = dataset_utils.crop_image(bounding_mask, crop_box)

        return image, mask, bounding_mask, crop_box

    @staticmethod
    def resize(image, mask, bounding_mask, output_height, output_width):
        image = cv2.resize(image, (output_width, output_height), interpolation=cv2.INTER_LINEAR)
        mask = cv2.resize(mask, (output_width, output_height), interpolation=cv2.INTER_LINEAR)
        mask = (mask > 0.5).astype(np.float32)
        bounding_mask = cv2.resize(bounding_mask, (output_width, output_height), interpolation=cv2.INTER_LINEAR)
        bounding_mask = (bounding_mask > 0.5).astype(np.float32)
        return image, mask, bounding_mask

    @staticmethod
    def gaussian_noise(image, mean=0, stddev=0.01):
        """
        :param image: np.uint8
        """
        noise = (np.random.normal(mean, stddev, image.shape) * 255).astype(np.uint8)
        image += noise
        return image


class TrainDataset(BaseDataset):

    def __init__(self, sequence, input_height, input_width, min_margin, max_margin,
                 flip_rate, degree, blur_rate, blur_mode, noise):
        super().__init__(sequence)
        self.input_height = input_height
        self.input_width = input_width
        self.flip_rate = flip_rate
        self.min_margin = min_margin
        self.max_margin = max_margin
        self.degree = degree
        self.blur_rate = blur_rate
        self.blur_mode = blur_mode
        self.noise = noise

    def get_positive_pair(self, index):
        image_cur, mask_cur = self.get_image_mask(index)

        num_frames = self.sequence[index]['num_frames']
        frame_index = self.sequence[index]['frame_index']
        index_ref = random.randint(index - frame_index, index - frame_index + num_frames - 1)

        image_ref, mask_ref = self.get_image_mask(index_ref)

        return image_ref, mask_ref, image_cur, mask_cur

    def get_previous_mask(self, index):
        if self.sequence[index]['frame_index'] == 0:
            index_prev = index
        else:
            index_prev = index - 1

        _, mask_prev = self.get_image_mask(index_prev)

        return mask_prev

    def process_image_mask(self, image, mask, bounding_mask, output_height, output_width):
        # flip
        if random.random() < self.flip_rate:
            image, mask, bounding_mask = self.flip(image, mask, bounding_mask)

        # rotate
        degree = random.uniform(-self.degree, self.degree)
        image, mask, bounding_mask = self.rotate(image, mask, bounding_mask, degree)

        # crop
        margin_top, margin_bottom, margin_left, margin_right = [random.uniform(self.min_margin, self.max_margin) for _ in range(4)]
        image, mask, bounding_mask, crop_box = self.crop(image, mask, bounding_mask, margin_left, margin_right,
                                                         margin_top, margin_bottom)

        # resize
        image, mask, bounding_mask = self.resize(image, mask, bounding_mask, output_height, output_width)

        # gaussian noise
        if self.noise:
            image = self.gaussian_noise(image, stddev=random.uniform(0.01, 0.1))

        return image, mask, bounding_mask, crop_box

    def __getitem__(self, index):

        image_ref, mask_ref, image_cur, mask_cur = self.get_positive_pair(index)
        mask_prev = self.get_previous_mask(index)

        image_ref, mask_ref, _, _ = self.process_image_mask(image_ref, mask_ref, mask_ref.copy(), self.input_height,
                                                            self.input_width)
        image_cur, mask_cur, mask_prev, crop_box = self.process_image_mask(image_cur, mask_cur, mask_prev,
                                                                           self.input_height, self.input_width)

        # blur previous mask
        if random.random() < self.blur_rate:
            if self.blur_mode == 'edge':
                mask_prev = cv2.GaussianBlur(mask_prev, (31, 31), 0)
                if mask_prev.max() > 0:
                    mask_prev /= mask_prev.max()
                mask_prev = (mask_prev > 0.5).astype(np.float32)
            else:
                mask_prev = dataset_utils.get_gb_image(mask_prev)

        # transform to tensor
        image_cur = self.image_transform(image_cur)
        image_ref = self.image_transform(image_ref)

        mask_cur = torch.tensor(mask_cur, dtype=torch.float32).unsqueeze(0)
        mask_ref = torch.tensor(mask_ref, dtype=torch.float32).unsqueeze(0)
        mask_prev = torch.tensor(mask_prev, dtype=torch.float32).unsqueeze(0)

        return image_ref, mask_ref, image_cur, mask_cur, mask_prev, crop_box


class TestDataset(BaseDataset):

    def __init__(self, sequence, input_height, input_width, margin):
        super().__init__(sequence)
        self.input_height = input_height
        self.input_width = input_width
        self.margin = margin
        self.mask_prev = None

    def process_image_mask(self, image, mask, bounding_mask, output_height, output_width):
        image, mask, bounding_mask, crop_box = self.crop(image, mask, bounding_mask, self.margin, self.margin,
                                                         self.margin, self.margin)
        image, mask, bounding_mask = self.resize(image, mask, bounding_mask, output_height, output_width)

        return image, mask, bounding_mask, crop_box

    def __getitem__(self, index):

        image_cur, mask_cur = self.get_image_mask(index)
        image_ref, mask_ref = self.get_image_mask(index - self.sequence[index]['frame_index'])

        if self.sequence[index]['frame_index'] == 0:
            mask_prev = mask_cur
        else:
            mask_prev = self.mask_prev

        image_ref, mask_ref, _, _ = self.process_image_mask(image_ref, mask_ref, mask_ref.copy(), self.input_height,
                                                            self.input_width)
        image_cur, mask_cur, mask_prev, crop_box = self.process_image_mask(image_cur, mask_cur, mask_prev,
                                                                           self.input_height, self.input_width)

        # transform to tensor
        image_cur = self.image_transform(image_cur)
        image_ref = self.image_transform(image_ref)

        mask_cur = torch.tensor(mask_cur, dtype=torch.float32).unsqueeze(0)
        mask_ref = torch.tensor(mask_ref, dtype=torch.float32).unsqueeze(0)
        mask_prev = torch.tensor(mask_prev, dtype=torch.float32).unsqueeze(0)

        return image_ref, mask_ref, image_cur, mask_cur, mask_prev, crop_box
