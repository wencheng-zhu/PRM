import json
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-split', type=str, required=True)
    parser.add_argument('--output-split', type=str, required=True)
    parser.add_argument('--multiple', type=int, required=True)
    args = parser.parse_args()
    
    with open(args.input_split, 'r') as f:
        split = json.load(f)

    output_split = []
    for frame_info in split:
        if frame_info['frame_index'] == 0:
            frame_info['num_frames'] = 1
            output_split.append(frame_info)

    output_split *= args.multiple

    with open(args.output_split, 'w') as f:
        json.dump(output_split, f, indent=4, separators=(',', ': '))


if __name__ == "__main__":
    main()
