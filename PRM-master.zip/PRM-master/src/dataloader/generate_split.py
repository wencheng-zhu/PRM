import os
import json
import argparse
from PIL import Image
import numpy as np
from pathlib import Path


def generate_split_youtube(video_root, label_root, meta_filename, is_test):

    with open(meta_filename, 'r') as f:
        meta = json.load(f)

    split_info = []

    for video_name, video in meta['videos'].items():
        for object_index, obj in video['objects'].items():
            mask_path = None

            for frame_index, frame in enumerate(obj['frames']):
                object_index = int(object_index)
                image_path = os.path.join(video_root, video_name, f'{frame}.jpg')

                if frame_index == 0 or not is_test:
                    mask_path = os.path.join(label_root, video_name, f'{frame}.png')

                num_frames = len(obj['frames'])

                video_info = {'image_path': os.path.realpath(image_path),
                              'mask_path': os.path.realpath(mask_path),
                              'video_name': video_name,
                              'num_frames': num_frames,
                              'frame_index': frame_index,
                              'object_index': object_index}

                split_info.append(video_info)

        print("processing: " + video_name)

    return split_info


def generate_split_davis(video_root, label_root, valid_videos, is_test):
    split_info = []

    for video_name in os.listdir(video_root):
        if video_name not in valid_videos:
            continue
        video_dir = os.path.join(video_root, video_name)
        label_dir = os.path.join(label_root, video_name)

        image_basenames = sorted([f for f in os.listdir(video_dir) if f.endswith('.jpg')])
        mask_basenames = sorted([f for f in os.listdir(label_dir) if f.endswith('.png')])

        if is_test:
            assert len(mask_basenames) == 1
            mask_basenames *= len(image_basenames)
        else:
            assert len(image_basenames) == len(mask_basenames)
            assert [os.path.splitext(f)[0] for f in image_basenames] == [os.path.splitext(f)[0] for f in mask_basenames]

        image_paths = [os.path.join(video_dir, f) for f in image_basenames]
        mask_paths = [os.path.join(label_dir, f) for f in mask_basenames]

        mask_first = np.array(Image.open(mask_paths[0]))
        object_indices = [int(x) for x in np.unique(mask_first) if x != 0]

        num_frames = len(image_basenames)

        for object_index in object_indices:
            video_info = [{'image_path': os.path.realpath(image_path),
                           'mask_path': os.path.realpath(mask_path),
                           'video_name': video_name,
                           'num_frames': num_frames,
                           'frame_index': frame_index,
                           'object_index': object_index}
                          for frame_index, (image_path, mask_path) in enumerate(zip(image_paths, mask_paths))]

            split_info += video_info

        print("processing: " + video_dir)

    return split_info


def generate_split_coco(img_dir, mask_dir):
    img_dir = Path(img_dir)
    mask_dir = Path(mask_dir)
    split_info = []
    for img_idx, img_path in enumerate(img_dir.glob('*.jpg')):
        if img_idx % 100 == 0:
            print(img_idx, img_path)
        mask_path = mask_dir / f'{img_path.stem}.png'
        mask = Image.open(str(mask_path))
        obj_ids = sorted(np.unique(mask))
        for obj_id in obj_ids:
            if obj_id > 0:
                split_info.append(dict(image_path=str(img_path.resolve()), mask_path=str(mask_path.resolve()), 
                        video_name='coco', num_frames=1, frame_index=0, object_index=int(obj_id)))
    return split_info


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, required=True, choices=['davis2017', 'davis2016', 'youtube', 'coco'])
    parser.add_argument('--dataset-type', type=str, required=True, choices=['train', 'val', 'test'])
    parser.add_argument('--output-dir', type=str, default='../splits')
    args = parser.parse_args()

    with open('dataset_config.json', 'r') as f:
        dataset_config = json.load(f)

    config = dataset_config[args.dataset][args.dataset_type]

    if args.dataset == 'youtube':
        split_info = generate_split_youtube(config['video_root'], config['label_root'], config['meta_path'], args.dataset_type == 'test')
    elif args.dataset == 'coco':
        split_info = generate_split_coco(config['image_dir'], config['mask_dir'])
    else:
        split_info = generate_split_davis(config['video_root'], config['label_root'], config['valid_videos'], args.dataset_type == 'test')

    os.makedirs(args.output_dir, exist_ok=True)
    with open(os.path.join(args.output_dir, f'split_{args.dataset}_{args.dataset_type}.json'), 'w') as f:
        json.dump(split_info, f, indent=4, separators=(',', ': '))


if __name__ == "__main__":
    main()
